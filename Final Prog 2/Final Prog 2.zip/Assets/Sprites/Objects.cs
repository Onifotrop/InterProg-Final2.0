﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Objects : MonoBehaviour
{
    //Abandoned
    //private GameObject player;
    //private Rigidbody2D rb;
    void Start()
    {
        //player = GameObject.Find("PlayerPlaceHolder");
        //rb = this.GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    // private void OnTriggerStay2D(Collider2D other)
    // {
    //     if (other.gameObject.CompareTag("Player"))
    //     {
    //         if (Input.GetMouseButton(1))
    //         {
    //             rb.AddForce((player.transform.position-this.transform.position)*50f,ForceMode2D.Force);
    //         }
    //     }
    //     
    // }

}
